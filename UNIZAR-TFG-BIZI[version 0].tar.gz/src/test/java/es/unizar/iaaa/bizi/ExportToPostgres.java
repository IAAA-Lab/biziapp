package es.unizar.iaaa.bizi;

import java.sql.SQLException;

public class ExportToPostgres {
	private static String driverName = "org.apache.hive.jdbc.HiveDriver";

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
		
	}

}
