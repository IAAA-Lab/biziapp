package es.unizar.iaaa.bizi.v0;

public enum Estado {
	ERROR, SUCCESSDOWNLOAD, SUCCESStoCSV, SUCCESStoHADOOP, SUCCESStoMYSQL;
}
