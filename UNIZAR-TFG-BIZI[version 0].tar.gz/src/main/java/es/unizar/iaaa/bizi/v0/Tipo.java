/**
 * Representa los diferentes tipos de ficheros que se pueden obtener desde la web clearchannel
 */
package es.unizar.iaaa.bizi.v0;

public enum Tipo {
	USOESTACION, MATRIZESTACION;
}
